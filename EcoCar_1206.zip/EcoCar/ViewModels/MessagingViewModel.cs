﻿using EcoCar.Models.MessagingManagement;

namespace EcoCar.ViewModels
{
    public class MessagingViewModel
    {
        public UserReporting userReporting { get; set; }
        public Message Message { get; set; }
    }
}
