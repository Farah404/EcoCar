﻿namespace EcoCar.Models.MessagingManagement
{
    public class Message
    {
        //Primary Key
        public int Id { get; set; }

        //Attributes
        public string MessageContent { get; set; }

        //Foreign Keys

        //Inheritance Class
    }
}
